<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Cielo" tilewidth="80" tileheight="176" tilecount="1" columns="1">
 <image source="Fondos/NonParallax.png" width="80" height="176"/>
</tileset>
